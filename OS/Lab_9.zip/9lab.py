import requests
import sys

file = open('requests.txt', 'w', encoding = 'utf-8')
sys.stdout = file

# 1. OPTIONS
print("\n1. метод options")
r = requests.options('https://httpbin.org/')
print(f"Код ответа: {r.status_code}")
print(f"Заголовки: {dict(r.headers)}")
print(f"Тело: {r.text}")

# 2. GET
print("\n2. метод get")
r = requests.get('https://httpbin.org/get', params={'name': 'Optimus Prime', 'team': 'auto-bot'})
print(f"Код ответа: {r.status_code}")
print(f"Заголовки: {dict(r.headers)}")
print(f"Тело: {r.text}")

# 3. POST
print("\n3. метод post")
data = {'name': 'differential calculus', 'mark': 4}
print(f"Тело запроса: {data}")
r = requests.post('https://httpbin.org/post', json = data)
print(f"Код ответа: {r.status_code}")
print(f"Заголовки: {dict(r.headers)}")
print(f"Тело: {r.text}")

file.close()