import imaplib
import email
import sys

file = open('lab_10/imap_log.txt', 'w', encoding='utf-8')
sys.stdout = file
sys.stderr = file

with open('lab_10/pass.txt') as p:
    password = p.read()

login = 'aadyakonov@stud.kantiana.ru'

server = imaplib.IMAP4_SSL('imap.yandex.ru', 993)
server.debug = 4
server.login(login, password)
server.select('inbox')

id = server.search(None, 'ALL')[1][0].split()
print(f'Писем: {len(id)}\n')

for i in id[-5:]:
    raw = server.fetch(i, '(RFC822)')[1][0][1]
    msg = email.message_from_bytes(raw)
    print(f'Тема: {msg["Subject"]}')

server.close()
server.logout()

file.close()