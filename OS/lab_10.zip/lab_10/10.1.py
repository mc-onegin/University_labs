import smtplib
from email.mime.base import MIMEBase
from email import encoders
import sys

file = open('lab_10/smtp_log.txt', 'w', encoding='utf-8')
sys.stderr = file

with open('lab_10/pass.txt') as p:
    password = p.read()

login = 'aadyakonov@stud.kantiana.ru'

msg = MIMEBase('application', 'octet-stream')
msg.set_payload(open('lab_10/get.txt', 'rb').read())
encoders.encode_base64(msg)
msg.add_header('Content-Disposition', 'attachment', filename='get.txt')
msg['From'], msg['To'], msg['Subject'] = login, 'alexandr35412@gmail.com', 'you got offer for 250k/month'

with smtplib.SMTP_SSL('smtp.yandex.ru', 465) as server:
    server.set_debuglevel(1)
    server.login(login, password)
    server.send_message(msg)

file.close()